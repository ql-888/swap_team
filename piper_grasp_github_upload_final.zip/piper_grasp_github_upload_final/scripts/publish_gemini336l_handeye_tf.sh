#!/usr/bin/env bash
set -eo pipefail

source /opt/ros/humble/setup.bash
set -u

# The measured eye-to-hand calibration is
# piper_x/base_link_T_gemini336l_color_optical_frame.  The Orbbec driver owns
# gemini336l_link -> gemini336l_color_frame -> gemini336l_color_optical_frame,
# so publish the equivalent transform to the camera root instead of assigning
# a second parent directly to its optical frame.
# This static publisher does not open CAN or command the robot.
exec ros2 run tf2_ros static_transform_publisher \
  --x -0.4224818530563079 \
  --y 0.49140247522178726 \
  --z 0.6213174706225704 \
  --qx 0.05867726 \
  --qy 0.35479004 \
  --qz -0.23906441 \
  --qw 0.90195855 \
  --frame-id piper_x/base_link \
  --child-frame-id gemini336l_link
