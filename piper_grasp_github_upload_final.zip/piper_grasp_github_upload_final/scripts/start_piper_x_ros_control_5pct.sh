#!/usr/bin/env bash
set -eo pipefail

PROJECT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)

source /opt/ros/humble/setup.bash
source "${HOME}/agx_arm_ws/install/setup.bash"
set -u

exec ros2 launch agx_arm_ctrl start_single_agx_arm_rviz.launch.py \
  namespace:=piper_x \
  can_port:=can0 \
  arm_type:=piper_x \
  effector_type:=agx_gripper \
  auto_enable:=false \
  control_enabled:=true \
  speed_percent:=5 \
  follow:=true \
  custom_model:="${PROJECT_DIR}/assets/piper_x_description/urdf/piper_x_with_gripper_description.urdf" \
  tcp_offset:='[0.0,0.0,0.198,0.0,0.0,0.8412486994612669]'
