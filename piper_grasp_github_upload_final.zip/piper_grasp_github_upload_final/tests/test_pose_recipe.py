from pathlib import Path

import pytest
import yaml

from piper_pink.pose_io import load_object_pose
from piper_pink.recipe import GraspRecipe


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_example_pose_and_recipe_match():
    pose = load_object_pose(PROJECT_ROOT / "config/object_pose.example.yaml")
    recipe = GraspRecipe.load(PROJECT_ROOT / "config/grasp_recipe.example.yaml")
    assert pose.object_id == recipe.object_id
    assert pose.frame_id == "base_link"
    assert recipe.pregrasp_distance_m > 0.0
    assert recipe.execution_ready is False


def test_recipe_rejects_empty_axial_candidates(tmp_path):
    path = tmp_path / "recipe.yaml"
    path.write_text(
        yaml.safe_dump(
            {
                "object_id": "part",
                "object_from_tcp": [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]],
                "axial_angles_deg": [],
                "pregrasp_distance_m": 0.1,
                "retreat_distance_m": 0.1,
                "gripper_opening_m": 0.05,
                "gripper_closed_m": 0.01,
                "execution_ready": False,
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="axial"):
        GraspRecipe.load(path)


def test_drone_recipe_accepts_85mm_gripper_opening():
    recipe = GraspRecipe.load(
        PROJECT_ROOT / "config/grasp_recipe_drone_apriltag_top.yaml"
    )
    assert recipe.gripper_opening_m == pytest.approx(0.085)
    assert recipe.gripper_closed_m == pytest.approx(0.063)
    assert recipe.object_from_tcp[2, 3] == pytest.approx(-0.040)
