from pathlib import Path

import numpy as np

from piper_pink.calibration import HandEyeCalibration


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_orbbec_fixed_teammate_result_is_runtime_loadable():
    calibration = HandEyeCalibration.load(
        PROJECT_ROOT / "config" / "handeye_orbbec_fixed.yaml"
    )
    assert calibration.camera_mount == "fixed"
    assert calibration.parent_frame == "base_link"
    assert calibration.camera_frame == "camera_color_optical_frame"
    assert np.allclose(
        calibration.parent_from_camera[:3, 3],
        [-0.4224818530563079, 0.49140247522178726, 0.6213174706225704],
    )


def test_d435i_result_uses_confirmed_flange_parent():
    calibration = HandEyeCalibration.load(
        PROJECT_ROOT / "config" / "handeye_d435i_wrist_end_pose.yaml"
    )
    assert calibration.camera_mount == "wrist"
    assert calibration.parent_frame == "flange_link"
    assert calibration.camera_frame == "d435i_color_optical_frame"
    assert np.isclose(np.linalg.det(calibration.parent_from_camera[:3, :3]), 1.0)
