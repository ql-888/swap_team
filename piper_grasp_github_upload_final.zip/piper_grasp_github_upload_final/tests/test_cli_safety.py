from pathlib import Path

from piper_pink.__main__ import main


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_execute_confirmation_is_checked_before_can_access(capsys):
    result = main(
        [
            "grasp",
            "--object-pose",
            str(PROJECT_ROOT / "config/object_pose.example.yaml"),
            "--recipe",
            str(PROJECT_ROOT / "config/grasp_recipe.example.yaml"),
            "--execute",
        ]
    )
    captured = capsys.readouterr()
    assert result == 2
    assert "I_HAVE_CLEARED_THE_WORKSPACE" in captured.err
    assert "can0" not in captured.err


def test_missing_can_is_reported_without_sdk_traceback(capsys):
    result = main(["read-arm", "--can", "definitely_missing_can"])
    captured = capsys.readouterr()
    assert result == 1
    assert "does not exist" in captured.err


def test_test_points_confirmation_is_checked_before_can_access(capsys):
    result = main(
        [
            "test-points",
            "--points",
            str(PROJECT_ROOT / "config/test_points.example.yaml"),
            "--execute",
            "--can",
            "definitely_missing_can",
        ]
    )
    captured = capsys.readouterr()
    assert result == 2
    assert "I_HAVE_CLEARED_THE_WORKSPACE" in captured.err
    assert "definitely_missing_can" not in captured.err


def test_pregrasp_confirmation_is_checked_before_can_access(capsys):
    result = main(
        [
            "pregrasp",
            "--object-pose",
            str(PROJECT_ROOT / "config/object_pose.example.yaml"),
            "--recipe",
            str(PROJECT_ROOT / "config/grasp_recipe_apriltag_top.yaml"),
            "--execute",
            "--can",
            "definitely_missing_can",
        ]
    )
    captured = capsys.readouterr()
    assert result == 2
    assert "I_CONFIRM_PREGRASP_ONLY" in captured.err
    assert "definitely_missing_can" not in captured.err
