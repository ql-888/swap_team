# 队友手眼标定交付件

本目录由 `handeye_in.zip` 和 `handeye_to.zip` 精简提取而来。两个原 ZIP 都是
完整 ROS 工作区，包含重复的 `piper_ros`、`aruco_ros`、`.git`、`build`、
`install`、`log` 和缓存；这些与结果无关的内容没有复制进 `piper_grasp`。

## 已采用的结果

- `raw/orbbec_eye_to_hand_2026-08-12_16-17-08.{json,yaml}`：Gemini 336L
  固定全局相机，16 组样本，输出 `base_T_camera`。运行配置为
  `../config/handeye_orbbec_fixed.yaml`。
- `raw/d435i_eye_in_hand_2026-08-13_16-19-35.json`：D435i 腕部局部相机，
  30 组样本，输出解释为 `flange_link_T_camera`。对应运行配置为
  `../config/handeye_d435i_wrist_end_pose.yaml`。

Orbbec 原结果的父坐标名 `base` 已由设备安装人员确认为本项目的 `base_link`，
即同一个机械臂底座物理原点。D435i 原结果使用 Piper ROS `/end_pose`；发布代码
直接读取 Piper SDK `GetArmEndPoseMsgs()`，SDK 自带 TCP 示例将该数据明确作为
`J6 Pos`，再另行叠加工具偏移计算 `TCP Pos`。Piper X URDF 中
`link6 -> flange_link` 是零位移、零旋转固定连接，因此本项目将该标定结果规范为
`flange_link_T_camera`，不会叠加已标定的 198 mm TCP。

## 标定质量记录

|相机|模式|样本|平移 RMS|旋转 RMS|原结果状态|
|---|---:|---:|---:|---:|---|
|Gemini 336L|eye-to-hand|16|10.419 mm|0.991°|`quality_passed: true`|
|D435i|eye-in-hand|30|6.226 mm|0.673°|`completed`|

这两组结果都高于旧 `piper_grasp` 文档曾写的 2 mm / 0.5° 参考阈值，因而文档
保留实际残差，不把“已完成”写成“已达到毫米级抓取精度”。实际闭环控制前仍应
用未参与标定的检查点验证方向、尺度和重复误差。

## 队友源码快照

- `teammate_tools/handeye_in_legacy`：生成 D435i 当前结果的旧 `/end_pose` 版本。
- `teammate_tools/handeye_to_current`：较新的 ChArUco、五算法和 rqt 版本。

它们是可追溯快照，不是当前 `piper_grasp` 的直接运行入口。较新 launch 仍使用
队友机器上的 `piper` 包、`/joint_states_feedback` 和 `~/gy_ws/handeye` 路径，
而本机使用 `agx_arm_ctrl`、`/piper_x/feedback/joint_states` 和
`~/robot_projects/piper_grasp`。后续如需重新标定，应先完成 ROS 接口适配。

D435i 原始结果记录的 `stereo_gazebo_left_camera_optical_frame` 来自旧
`aruco_ros/launch/single.launch.py` 手工拼接的固定参数；该节点把参数原样写入
`/aruco_single/pose.header.frame_id`，并没有沿用输入图像真实的坐标名称。当前
D435i 的 `/sensors/d435i/color/image_raw` 与 `color/camera_info` 已实测均为
`d435i_color_optical_frame`，因此运行配置已将名称规范为该真实光学坐标。这里只
修正错误标签，未对标定矩阵施加任何额外旋转或平移。

## 原始 ZIP 校验值

```text
handeye_in.zip  sha256 1f82540ca944f85d6f10cf0c5d16cf080fbd5410c84f39b64eebf051ef2aeb3e
handeye_to.zip  sha256 83891c59bb3406e30ce1755681996708e6e4cbae2a1c408d3094736c82a0dc5a
```
