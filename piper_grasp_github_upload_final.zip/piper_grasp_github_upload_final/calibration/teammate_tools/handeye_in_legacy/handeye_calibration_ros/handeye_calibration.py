#!/usr/bin/env python3
# -*-coding:utf8-*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Pose
import tf_transformations
from scipy.spatial.transform import Rotation
import cv2
import numpy as np
import json
import datetime
import sys
import termios
import tty
import time
import os

def clear_input_buffer():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

def create_dir(dir=""):
    if dir == "" or dir == "/":
        exit(-1)
    if not os.path.exists(dir) or not os.path.isdir(dir):
        try:
            if os.path.exists(dir):
                os.remove(dir)
            os.makedirs(dir)
        except IOError:
            print("cannot create directory: " + dir)
            exit(-2)

def create_pose_from_martix(translation_matrix, rotation_matrix) -> Pose:
    rotation_matrix_4x4 = rotation_matrix_4x4 = np.eye(4)
    rotation_matrix_4x4[:3, :3] = rotation_matrix
    quaternion = tf_transformations.quaternion_from_matrix(rotation_matrix_4x4)

    pose = Pose()
    pose.position.x = translation_matrix[0][0]
    pose.position.y = translation_matrix[1][0]
    pose.position.z = translation_matrix[2][0]
    pose.orientation.x = quaternion[0]
    pose.orientation.y = quaternion[1]
    pose.orientation.z = quaternion[2]
    pose.orientation.w = quaternion[3]
    return pose

def pose_to_dict(pose: Pose):
    return {
        "position": {
            "x": float(pose.position.x),
            "y": float(pose.position.y),
            "z": float(pose.position.z),
        },
        "orientation": {
            "x": float(pose.orientation.x),
            "y": float(pose.orientation.y),
            "z": float(pose.orientation.z),
            "w": float(pose.orientation.w),
        },
    }

def matrix_from_pose(pose: Pose):
    matrix = np.eye(4)
    matrix[:3, :3] = Rotation.from_quat([
        pose.orientation.x,
        pose.orientation.y,
        pose.orientation.z,
        pose.orientation.w,
    ]).as_matrix()
    matrix[:3, 3] = [pose.position.x, pose.position.y, pose.position.z]
    return matrix

class PoseMartix():
    def __init__(self, pose_input: Pose, check_mode=False, mode='eye_in_hand'):
        position = pose_input.position
        orientation = pose_input.orientation
        self.position_list = [position.x, position.y, position.z]
        self.orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        self.rpy_list = [tf_transformations.euler_from_quaternion(self.orientation_list)]
        self.translation_matrix = np.array(self.position_list)
        self.rotation_matrix = Rotation.from_quat(self.orientation_list).as_matrix()
        # self.rotation_matrix = tf_transformations.quaternion_matrix(orientation)[:3, :3]
        if check_mode and mode == 'eye_to_hand':
            T = np.eye(4)
            T[:3, :3] = self.rotation_matrix
            T[:3, 3] = self.translation_matrix
            T_inv = np.linalg.inv(T)
            self.rotation_matrix = T_inv[:3, :3]
            self.translation_matrix = T_inv[:3, 3]

class HandEyeCalibrationNode(Node):
    def __init__(self):
        super().__init__("handeye_calibration")

        # Declare parameters
        self.declare_parameter('mode', 'eye_in_hand')
        self.declare_parameter('min_num', 10)
        self.declare_parameter('piper_topic', '/piper_ctrl_node/end_pose')
        self.declare_parameter('marker_topic', '/aruco_single/pose')
        self.declare_parameter('result_save_path', './result')
        # "/aruco_single/pose", "/piper_ctrl_node/end_pose"

        self.mode = self.get_parameter('mode').get_parameter_value().string_value
        self.min_num = self.get_parameter('min_num').get_parameter_value().integer_value
        self.piper_topic = self.get_parameter('piper_topic').get_parameter_value().string_value
        self.marker_topic = self.get_parameter('marker_topic').get_parameter_value().string_value
        self.result_save_path = self.get_parameter('result_save_path').get_parameter_value().string_value

        print(f"mode: {self.mode}")
        print(f"min_num: {self.min_num}")
        print(f"piper_topic: {self.piper_topic}")
        print(f"marker_topic: {self.marker_topic}")
        print(f"result_save_path: {self.result_save_path}")

        self.piper_poses = []
        self.marker_poses = []
        self.samples = []
        self.session_started_at = datetime.datetime.now().astimezone().isoformat()
        self.session_id = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        create_dir(self.result_save_path)
        self.samples_save_path = os.path.join(
            self.result_save_path, f"{self.session_id}_samples.json")
        self.save_session("collecting")

    def save_session(self, status, result=None, consistency=None):
        data = {
            "session_started_at": self.session_started_at,
            "status": status,
            "mode": self.mode,
            "parameters": {
                "min_num": self.min_num,
                "piper_topic": self.piper_topic,
                "marker_topic": self.marker_topic,
            },
            "sample_count": len(self.samples),
            "samples": self.samples,
        }
        if result is not None:
            data["calibration_result"] = result
        if consistency is not None:
            data["consistency"] = consistency

        temp_path = self.samples_save_path + ".tmp"
        with open(temp_path, 'w') as json_file:
            json.dump(data, json_file, indent=4)
        os.replace(temp_path, self.samples_save_path)

    def calculate_eye_in_hand_consistency(self, result_pose):
        if self.mode != "eye_in_hand":
            return None

        T_ee_cam = np.eye(4)
        T_ee_cam[:3, :3] = result_pose.rotation_matrix
        T_ee_cam[:3, 3] = result_pose.translation_matrix
        base_marker_transforms = []
        for sample in self.samples:
            piper_pose = Pose()
            marker_pose = Pose()
            for pose, source in (
                (piper_pose, sample["piper_pose"]),
                (marker_pose, sample["marker_pose"]),
            ):
                pose.position.x = source["position"]["x"]
                pose.position.y = source["position"]["y"]
                pose.position.z = source["position"]["z"]
                pose.orientation.x = source["orientation"]["x"]
                pose.orientation.y = source["orientation"]["y"]
                pose.orientation.z = source["orientation"]["z"]
                pose.orientation.w = source["orientation"]["w"]
            base_marker_transforms.append(
                matrix_from_pose(piper_pose) @ T_ee_cam @ matrix_from_pose(marker_pose))

        translations = np.array([T[:3, 3] for T in base_marker_transforms])
        translation_mean = translations.mean(axis=0)
        translation_errors = np.linalg.norm(translations - translation_mean, axis=1)
        rotations = Rotation.from_matrix([T[:3, :3] for T in base_marker_transforms])
        mean_rotation = rotations.mean()
        rotation_errors = (mean_rotation.inv() * rotations).magnitude()

        return {
            "description": "Fixed marker consistency in the robot base frame",
            "translation_mean_m": translation_mean.tolist(),
            "translation_rmse_mm": float(np.sqrt(np.mean(translation_errors ** 2)) * 1000.0),
            "translation_max_mm": float(np.max(translation_errors) * 1000.0),
            "rotation_rmse_deg": float(np.degrees(np.sqrt(np.mean(rotation_errors ** 2)))),
            "rotation_max_deg": float(np.degrees(np.max(rotation_errors))),
            "per_sample": [
                {
                    "index": sample["index"],
                    "translation_error_mm": float(translation_error * 1000.0),
                    "rotation_error_deg": float(np.degrees(rotation_error)),
                }
                for sample, translation_error, rotation_error in zip(
                    self.samples, translation_errors, rotation_errors)
            ],
        }

    def process_handeye(self):
        R_gripper2base = [data.rotation_matrix for data in self.piper_poses]
        t_gripper2base = [data.translation_matrix for data in self.piper_poses]
        R_target2cam = [data.rotation_matrix for data in self.marker_poses]
        t_target2cam = [data.translation_matrix for data in self.marker_poses]
        ret_R, ret_t = cv2.calibrateHandEye(R_gripper2base, t_gripper2base, R_target2cam, t_target2cam)
        return PoseMartix(create_pose_from_martix(ret_t, ret_R))

    def run(self):
        if self.mode != "eye_in_hand" and self.mode != "eye_to_hand":
            raise ValueError("'mode' 必须为 eye_in_hand 或 eye_to_hand ")
        if self.min_num < 5:
            raise ValueError("最少采集次数不得小于5次")
        self.get_poses()
        result_pose = self.process_handeye()
        result = dict(
            position = result_pose.position_list,
            orientation = result_pose.orientation_list,
            rpy = result_pose.rpy_list
        )
        consistency = self.calculate_eye_in_hand_consistency(result_pose)

        print("标定结果:")
        print("")
        print(json.dumps(result, indent=4))
        print("")
        if consistency is not None:
            print("一致性误差:")
            print(json.dumps(consistency, indent=4))
            print("")
        final_path = os.path.join(
            self.result_save_path, f"{self.session_id}_calibration.json")
        self.save_session("completed", result, consistency)
        os.replace(self.samples_save_path, final_path)
        self.samples_save_path = final_path
        print(f"writing all samples and result to {final_path}")

    def get_poses(self):
        count = 1
        while True:
            print(f"\n------- 第{count}次采集 ------")
            if count == 1:
                menu_str = "请输入(Enter-采集):"
            elif count <= self.min_num:
                menu_str = "请输入(Enter-采集, d-回退):"
            else:
                menu_str = "请输入(Enter-采集, d-回退, q-计算并退出):"
            try:
                clear_input_buffer()
                user_input = input(menu_str+" ")
                if user_input == '':
                    marker_pose_raw, marker_received_ns, piper_pose_raw, piper_received_ns = self.subscribe_message()
                    piper_pose = PoseMartix(piper_pose_raw, True, self.mode)
                    marker_pose = PoseMartix(marker_pose_raw.pose, False, self.mode)
                    print("---")
                    print(f"piper: {piper_pose.position_list}")
                    print(f"piper orientation: {piper_pose.orientation_list}")
                    print(f"marker: {marker_pose.position_list}")
                    print(f"marker orientation: {marker_pose.orientation_list}")
                    self.piper_poses.append(piper_pose)
                    self.marker_poses.append(marker_pose)
                    self.samples.append({
                        "index": len(self.samples) + 1,
                        "captured_at": datetime.datetime.now().astimezone().isoformat(),
                        "piper_received_time_ns": piper_received_ns,
                        "marker_received_time_ns": marker_received_ns,
                        "marker_header": {
                            "frame_id": marker_pose_raw.header.frame_id,
                            "stamp": {
                                "sec": marker_pose_raw.header.stamp.sec,
                                "nanosec": marker_pose_raw.header.stamp.nanosec,
                            },
                        },
                        "piper_pose": pose_to_dict(piper_pose_raw),
                        "marker_pose": pose_to_dict(marker_pose_raw.pose),
                    })
                    count += 1
                    self.save_session("collecting")
                    print(f"saved sample {len(self.samples)} to {self.samples_save_path}")
                elif count > 1 and user_input == 'd':
                    count -= 1
                    self.piper_poses.pop()
                    self.marker_poses.pop()
                    self.samples.pop()
                    self.save_session("collecting")
                    print(f"deleted last sample; {len(self.samples)} samples remain")
                elif user_input == 'c':
                    print("exit")
                    self.save_session("cancelled")
                    exit(0)
                elif count > self.min_num and user_input == 'q':
                    print("开始计算标定结果")
                    break
                else:
                    print("无效输入")
            except Exception as e:  # Exception as e
                #exit(0)
                #pass
                #print(e)
                print("\n程序异常或中断退出")
                exit(-1)	# -3

    def callback(self, msg):
        self.get_msg=True
        self.call_msg = msg
        self.call_received_ns = self.get_clock().now().nanoseconds

    def subscribe_message(self):
        sys.stdout.write("wait marker data... ")
        sys.stdout.flush()
        marker_pose_raw, marker_received_ns = self.subcribe_one_message(self.marker_topic, PoseStamped)
        sys.stdout.write("[ok]\n")

        sys.stdout.write("wait piper data... ")
        sys.stdout.flush()
        piper_pose_raw, piper_received_ns = self.subcribe_one_message(self.piper_topic, Pose)
        sys.stdout.write("[ok]\n")

        return marker_pose_raw, marker_received_ns, piper_pose_raw, piper_received_ns

    def subcribe_one_message(self, topic, msg_type):
        self.get_msg=False
        sub = self.create_subscription(msg_type, topic, self.callback, 1)
        while not self.get_msg:
            rclpy.spin_once(self)
            time.sleep(0.05) 
        msg = self.call_msg
        received_ns = self.call_received_ns
        self.destroy_subscription(sub)
        return msg, received_ns

def main(args=None):
    rclpy.init(args=args)
    calibration_node = HandEyeCalibrationNode()
    calibration_node.run()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
