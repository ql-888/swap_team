# Piper X 精确抓取工程

> 本副本已针对 Piper X 适配：使用 `agx_arm_ros` 官方 Piper X 带夹爪
> URDF/网格，并按 Piper X 的 joint4/joint5 限位构建 Pinocchio 模型。
> 默认 TCP 已设为当前实物总成的标定结果：相对 `flange_link` 的
> `[0, 0, 0.198] m / [0, 0, 48.2] degree`。其中 Z 来自 TCP 枢轴标定，
> yaw 来自力传感器与夹爪重新安装后的三组水平开合方向观测。

这是一个面向 Ubuntu 22.04 和 AgileX Piper X 的完整抓取基础工程。它使用 Piper SDK 负责 CAN 通信，Pinocchio 负责机器人模型、正运动学和碰撞模型，Pink 负责带关节限位的多初值逆运动学，OpenCV ArUco 提供一个可替换的 6D 目标检测入口。

工程默认只做离线计算。真实运动必须同时提供 `--execute` 和精确确认字符串 `I_HAVE_CLEARED_THE_WORKSPACE`，否则不会使能机械臂。离线构建和验收命令不会打开 `can0`，也不会发送真实运动命令。

## 无人机腕部相机分段抓取运行指令

当前无人机标签为 `tag36h11`、ID `0`，实测黑框边长为 **29 mm**。无人机抓取配方保持两指从标签左右两侧夹取、接近方向倾斜 30 度，TCP 最终目标位于标签表面下方 40 mm；夹爪打开至 85 mm，闭合至 63 mm。

以下常驻程序分别在独立终端运行。终端 1 配置 CAN 后启动机械臂：

```bash
sudo ip link set can0 down 2>/dev/null || true
sudo ip link set can0 type can bitrate 1000000
sudo ip link set can0 txqueuelen 1000
sudo ip link set can0 up

cd ~/robot_projects/piper_grasp
./scripts/start_piper_x_ros_control_5pct.sh
```

终端 2 启动 D435i：

```bash
source /opt/ros/humble/setup.bash
ros2 launch realsense2_camera rs_launch.py \
  camera_namespace:=sensors \
  camera_name:=d435i \
  enable_color:=true \
  enable_depth:=false \
  enable_infra1:=false \
  enable_infra2:=false \
  pointcloud.enable:=false
```

终端 3 发布 D435i 手眼 TF：

```bash
cd ~/robot_projects/piper_grasp
./scripts/publish_d435i_handeye_tf.sh
```

终端 4 启动无人机专用 29 mm AprilTag 检测：

```bash
cd ~/robot_projects/piper_grasp
./scripts/run_apriltag_d435i_drone.sh
```

不得同时运行旧的 `run_apriltag_d435i.sh`，否则 18 mm 和 29 mm 节点会争用同一个标签 TF。

终端 5 检查节点、图像、检测和 TF：

```bash
source /opt/ros/humble/setup.bash
source ~/agx_arm_ws/install/setup.bash

ros2 topic info /piper_x/feedback/joint_states
ros2 topic info /sensors/d435i/color/image_raw
ros2 topic echo /perception/d435i/detections --once
ros2 run tf2_ros tf2_echo piper_x/base_link apriltag_0
```

在机械臂速度为 5%、工作区清空、无人机固定不动的前提下，按顺序逐段运行。第一步仅识别和离线规划，不运动机械臂：

```bash
cd ~/robot_projects/piper_grasp
./scripts/plan_d435i_drone_apriltag_grasp.sh
```

到达距离最终抓取位 100 mm 的预抓取位：

```bash
./scripts/run_d435i_drone_apriltag_ros_pregrasp.sh \
  I_CONFIRM_ROS_PREGRASP_ONLY
```

复用预抓取阶段锁定的标签位姿，到达 50 mm 检查位：

```bash
./scripts/run_d435i_drone_apriltag_ros_approach50.sh \
  I_CONFIRM_APPROACH_50MM_ONLY
```

确认无人机和标签未移动，再到达 25 mm 检查位：

```bash
./scripts/run_d435i_drone_apriltag_ros_approach25.sh \
  I_CONFIRM_APPROACH_25MM_ONLY \
  I_CONFIRM_OBJECT_AND_TAG_NOT_MOVED
```

肉眼确认两指位置正确后，执行最后 25 mm 运动并闭合至 63 mm：

```bash
./scripts/run_d435i_drone_locked_pose_grasp_close.sh \
  I_CONFIRM_FINAL_25MM_AND_CLOSE \
  I_CONFIRM_OBJECT_AND_TAG_NOT_MOVED
```

确认夹持稳定后，保持夹紧并撤离：

```bash
./scripts/run_drone_locked_pose_full_retreat.sh \
  I_CONFIRM_FULL_RETREAT_WITH_GRIP \
  I_CONFIRM_GRIP_IS_STABLE
```

每一阶段必须成功输出对应的 `*_COMPLETE` 后才能继续。任一步骤失败、无人机被移动、标签尺寸改变或机械臂实际位置与计划不符时，应停止流程并从首次识别重新规划。

## 已实现能力

- 项目内独立 Conda 环境，不污染 ROS 或系统 Python。
- Piper ROS 官方 URDF、网格和 MoveIt SRDF 随项目保存。
- 六轴 Pinocchio 模型、实测 TCP、FK 和 Pink 多初值全位姿 IK。
- 多个绕抓取轴的候选姿态，自动跳过不可达或碰撞候选。
- 当前位姿到预抓取、抓取、撤离的整段关节插值碰撞检查。
- 关节限位、工作空间、桌面/障碍物、自碰撞、NaN 和反馈超时保护。
- TCP 枢轴标定，以及已导入的 D435i 腕部相机和 Gemini 336L 固定相机手眼结果。
- ArUco 图像检测、统一目标位姿 YAML、物体抓取配方和运行报告。
- 只读采集 TCP/手眼样本；采样命令不会使能或移动机械臂。

## 目录

```text
piper_grasp/
  assets/                 Piper URDF、STL 和 SRDF
  calibration/            队友原始标定结果、质量记录和源码快照
  config/                 相机、场景、位姿、抓取和运行标定配置
  scripts/                环境、CAN、运行和测试脚本
  src/piper_pink/          规划、标定、视觉、碰撞和 SDK 桥接代码
  tests/                   离线单元与集成测试
```

## 1. 安装环境

最终项目目录为 `/home/shen_tao/robot_projects/piper_grasp`。首次安装：

```bash
cd /home/shen_tao/robot_projects/piper_grasp
./scripts/setup_env.sh
./scripts/run.sh doctor --handeye config/handeye_orbbec_fixed.yaml
./scripts/test.sh
./scripts/verify_offline.sh
```

环境安装在项目自己的 `.conda` 目录。以后不需要 `conda activate piper`，统一通过 `scripts/run.sh` 调用，脚本会清除 ROS 的 `PYTHONPATH`，避免 ROS Python 包污染 Pinocchio 环境。

已验证版本：Python 3.10、Pinocchio 4.1.0、Pink 4.3.0、OpenCV 5.0.0、Piper SDK 0.6.2。

## 2. CAN 驱动和当前 USB 情况

Piper SDK 的默认接口是 Linux SocketCAN `can0`，Piper 总线通常配置为 1 Mbit/s。插入兼容 `gs_usb` 的 USB-CAN 适配器后运行：

```bash
cd /home/shen_tao/robot_projects/piper_grasp
./scripts/setup_can.sh can0 1000000
ip -details -statistics link show can0
./scripts/run.sh doctor --require-can
./scripts/run.sh read-arm --can can0
```

此前系统日志只识别到以下设备：

- `2341:0043` Arduino，注册为 `ttyACM0`。
- `1a86:7523` CH341 USB 串口，曾注册为 `ttyUSB0`，随后被 BRLTTY 抢占。
- GenesysLogic USB 2/3 Hub。

这些记录里没有 USB-CAN 设备，所以加载 `gs_usb` 后仍不会出现 `can0`。Type-C 扩展坞本身没有问题，但必须接入真正支持 SocketCAN/`gs_usb` 的 USB-CAN 适配器。不要把普通 Arduino 或 CH341 USB 串口直接当成 Piper CAN 驱动；除非该设备明确烧录了 SLCAN 固件，并按 SLCAN 方式配置。

## 3. 离线验收

先确认模型和依赖：

```bash
./scripts/run.sh info
./scripts/run.sh doctor --handeye config/handeye_orbbec_fixed.yaml
```

运行示例抓取规划并保存可追踪报告：

```bash
./scripts/run.sh plan-grasp \
  --object-pose config/object_pose.example.yaml \
  --recipe config/grasp_recipe.example.yaml \
  --report logs/example_plan.yaml
```

示例目标已验证能够产生预抓取、抓取和撤离三段解，所有插值路点都经过自碰撞和场景碰撞检查。`plan-grasp` 不会打开 CAN。

## 4. 坐标和数据接口

所有长度在算法内部使用米，角度在算法内部使用弧度。Piper SDK 边界会将关节角转换成协议的 `0.001 degree`；夹爪开度转换成协议的 `0.001 mm`。

目标检测器需要生成与 `config/object_pose.example.yaml` 相同的文件：

```yaml
frame_id: camera_color_optical_frame
object_id: demo_block
confidence: 0.95
timestamp_s: 1786240000.0
frame_from_object: [[...], [...], [...], [0, 0, 0, 1]]
```

`frame_from_object` 是 `frame_id` 到物体坐标系的齐次变换。相机坐标系输入必须和手眼标定的 `camera_frame` 完全一致。真实抓取默认拒绝超过 2 秒或没有时间戳的目标位姿。

ArUco 示例：

```bash
./scripts/run.sh detect-aruco \
  --image /absolute/path/frame.png \
  --intrinsics config/camera_intrinsics.yaml \
  --marker-id 0 --marker-size-m 0.040 \
  --object-id demo_block --output /tmp/object_pose.yaml
```

`config/grasp_recipe.example.yaml` 中的 `object_from_tcp` 是物体坐标系下期望 TCP 位姿。每种物体、夹持方向和夹爪宽度应使用独立配方。

当前 D435i AprilTag 参数为 `tag36h11`、ID `0`、黑色编码方形边长
`18 mm`。D435i 驱动运行后，在另一个终端启动官方 AprilTag ROS 节点：

```bash
cd /home/shen_tao/robot_projects/piper_grasp
./scripts/run_apriltag_d435i.sh
```

检测结果发布在 `/perception/d435i/detections`，标签 TF 名为
`apriltag_0`。配置文件是 `config/apriltag_d435i.yaml`。

机械臂状态 TF 在线后，可在独立终端发布已标定的法兰到 D435i 静态变换：

```bash
cd /home/shen_tao/robot_projects/piper_grasp
./scripts/publish_d435i_handeye_tf.sh
```

标定结果本身是 `flange_link -> d435i_color_optical_frame`。由于 RealSense 驱动
已经发布 `d435i_link -> d435i_color_frame -> d435i_color_optical_frame`，脚本会
先把标定结果等价换算为 `flange_link -> d435i_link`，从 D435i 根坐标连接两棵
TF 树，避免给彩色光学坐标设置第二个父节点。随后用
`tf2_echo piper_x/base_link apriltag_0` 检查标签在机械臂底座坐标系中的位姿。

Gemini 336L 使用独立的标签坐标系 `gemini_apriltag_0`，避免与 D435i
的 `apriltag_0` 发生 TF 双父节点冲突：

```bash
./scripts/publish_gemini336l_handeye_tf.sh
./scripts/run_apriltag_gemini336l.sh
ros2 run tf2_ros tf2_echo piper_x/base_link gemini_apriltag_0
```

队友标定结果为 `base_link -> gemini336l_color_optical_frame`。因为 Orbbec
驱动已发布 `gemini336l_link -> gemini336l_color_frame ->
gemini336l_color_optical_frame`，脚本会等价换算并发布
`piper_x/base_link -> gemini336l_link`。

### D435i 顶部 AprilTag 两指抓取规划

`config/grasp_recipe_apriltag_top.yaml` 定义了当前抓取几何：

- AprilTag `+X` 作为左右方向，对应 Piper X TCP `+X` 的两指闭合方向；
- TCP 沿标签 `-Z` 进入物体 `25 mm`；
- 接近轴相对标签法向倾斜 `30°`，并绕标签 `X` 轴倾斜，因此不改变左右夹取方向；
- 预抓取和后退距离均为 `100 mm`。

在机械臂、D435i、D435i 手眼 TF 和 AprilTag 检测节点均运行时，
使用下列命令采集 30 帧并只做离线路径规划：

```bash
cd ~/robot_projects/piper_grasp
./scripts/plan_d435i_apriltag_grasp.sh
```

脚本会生成 `runtime/d435i_apriltag_object_pose.yaml` 和
`runtime/d435i_apriltag_grasp_plan.yaml`。该命令不打开 CAN、不使能、不移动
机械臂、不操作夹爪。

当前配方的 `execution_ready: false`是硬件执行锁。在实际执行前还必须测量
物体宽度并设置 `gripper_closed_m`，核对标签的 `25 mm` 抓取深度，
以及用实际桌面、物体、相机和支架尺寸补齐 `config/scene.yaml`。

首次真机测试使用专用的预抓取入口，速度限制为 `5%`，夹爪打开到
`70 mm`，并且只运动到预抓取点：

```bash
./scripts/run_d435i_apriltag_pregrasp.sh I_CONFIRM_PREGRASP_ONLY
```

该入口不会下降到抓取点、不会闭合夹爪、不会执行后退段。
由于本机 IK 和全路径碰撞检查实测需要约 `6-8 s`，该预抓取入口允许
从采集到开始动作最多 `15 s`；运行期间标签和物体必须刚性固定不动。
该脚本只发布 TF，不连接 CAN，也不发送机械臂控制命令。

## 5. TCP 标定

当前默认值是装好力传感器并重新安装夹爪后得到的实测 TCP：相对法兰盘
`X=0, Y=0, Z=198 mm, RX=0, RY=0, RZ=48.2 degree`。其中位置来自枢轴标定，
RZ 来自三组实际水平开合方向观测（49.672°、47.519°、47.392°）的综合估计。
只要工具总成没有改变，
无需重复标定。如果更换力传感器、转接板、夹爪或工具尖端，再把一个尖头固定
在夹爪上，使尖端始终接触同一空间点，改变腕部方向并记录至少 8 到 15 个差异明显的姿态：

```bash
./scripts/run.sh record-tcp-sample \
  --can can0 --samples calibration/tcp_samples.yaml
```

该命令只读取关节反馈。完成采样后：

```bash
./scripts/run.sh calibrate-tcp \
  --samples calibration/tcp_samples.yaml \
  --output calibration/tcp_result.yaml \
  --maximum-rms-mm 1.0
```

将输出的 `tcp_translation_m` 写入实际运行使用的 `--tcp-xyz-m` 或 `config/robot.yaml`。如果工具方向与默认值不同，还必须测量并设置 `--tcp-rpy-deg`。仅做枢轴法只能准确求出 TCP 位置，不能独立确定完整工具姿态。

## 6. 手眼标定

旧的单位矩阵占位配置和“从零采样”主流程已经移除，现采用两名队友交付的
标定结果。原始 JSON/YAML、样本、质量指标和精简源码均保存在
`calibration/`，详细出处见 `calibration/README.md`。

### Gemini 336L：固定全局相机

运行配置是 `config/handeye_orbbec_fixed.yaml`，内容为 16 组样本求得的
`base_T_camera`。原结果坐标名 `base` 已确认就是本机的 `base_link`，即机械臂
底座物理原点。可离线检查：

```bash
./scripts/run.sh validate-handeye \
  --calibration config/handeye_orbbec_fixed.yaml
./scripts/run.sh doctor --handeye config/handeye_orbbec_fixed.yaml
```

原结果标记 `quality_passed: true`；实测残差为平移 RMS 10.419 mm、最大
20.603 mm，旋转 RMS 0.991°、最大 2.121°。

### D435i：腕部局部相机

运行配置是 `config/handeye_d435i_wrist_end_pose.yaml`，来自 30 组样本，变换为
`flange_link_T_camera`。实测残差为平移 RMS 6.226 mm、最大 12.199 mm，旋转
RMS 0.673°、最大 1.467°。

这次采集读取旧 ROS 话题 `/end_pose`。发布代码直接读取 Piper SDK 的
`GetArmEndPoseMsgs()`；SDK 自带 TCP 示例把它称为 `J6 Pos`，并在此基础上另加
工具偏移才得到 `TCP Pos`。同时 Piper X URDF 中 `link6 -> flange_link` 是单位
变换，所以这里将 `/end_pose` 正式映射为 `flange_link`，不会错误叠加本项目
198 mm 的 TCP。运行时仍会按配置中的 `parent_frame` 查找模型坐标系。

原始结果中的相机名 `stereo_gazebo_left_camera_optical_frame` 是旧 ArUco launch
硬编码的示例标签，并非额外的物理 TF。当前 D435i 的彩色图像和 CameraInfo 已
实测统一发布 `d435i_color_optical_frame`，所以运行配置采用这个真实名称；标定
矩阵本身保持不变。

两组结果都已完成求解，但都高于旧文档的 2 mm / 0.5° 参考阈值。低残差也不
等于绝对准确，闭环控制前仍应在未参与标定的检查点验证相机到 TCP 的方向、尺度
和重复误差。相机、支架、力传感器或工具总成一旦拆装，相关结果必须重新验证或
重新标定。

### 全局 Gemini 相机到腕部 D435i 的完整抓取

全局相机流程用于在机械臂远离物体、腕部 D435i 看不到标签时先获得粗略目标位姿，
机械臂到达全局相机规划的观察位，再切换到腕部相机完成分段抓取。启动 Gemini
驱动后，在独立终端运行：

```bash
cd ~/robot_projects/piper_grasp
./scripts/publish_gemini336l_handeye_tf.sh
./scripts/run_apriltag_gemini336l.sh
```

检查全局标签 TF：

```bash
source /opt/ros/humble/setup.bash
ros2 run tf2_ros tf2_echo piper_x/base_link gemini_apriltag_0
```

需要同时确认 D435i、D435i 手眼 TF 和 D435i AprilTag 节点已经运行。全局到腕部
的完整分段流程由以下脚本执行：

```bash
cd ~/robot_projects/piper_grasp

./scripts/run_global_to_wrist_apriltag_grasp_retreat.sh \
  I_CONFIRM_GLOBAL_TO_WRIST_FULL_CYCLE \
  I_HAVE_CLEARED_THE_WORKSPACE \
  I_CONFIRM_OBJECT_STAYS_FIXED_DURING_RUN
```

该流程包含：

1. Gemini 全局相机采集 AprilTag 并锁定物体位姿。
2. 规划并移动到全局相机引导的腕部相机观察位。
3. 尝试用 D435i 获取标签；标签不可见时按脚本的安全策略复用已锁定位姿。
4. 依次执行 50 mm、25 mm 检查和最终抓取。
5. 保持夹爪闭合并完成撤离，不自动释放物体。

全局相机只用于粗定位，不能替代 D435i 腕部手眼标定。若需要只观察两个标签族
（`tag36h11` 和 `tagStandard52h13`）而不运动机械臂，可运行：

```bash
cd ~/robot_projects/piper_grasp
./scripts/run_gemini336l_dual_tag_live.sh
```

## 7. 场景和抓取规划

在 `config/scene.yaml` 中用 `base_link` 坐标系的长方体描述桌面、相机支架、料箱和围栏。真实运行前必须按现场测量更新尺寸和位置。规划器会：

1. 围绕抓取轴生成多个姿态。
2. 对每个姿态执行多初值 Pink IK。
3. 检查工作空间、关节限位和目标误差。
4. 检查当前位姿到预抓取、抓取和撤离的所有离散路径点。
5. 从全部可行候选中选择综合代价最低的解。

当前局部规划器验证关节空间直线，不会绕过障碍物。如果直线路径被阻挡，它会安全失败。需要在复杂货架或密集障碍物中绕行时，应在本工程模型和标定基础上接入 MoveIt 2/OMPL，再把生成轨迹交给相同的安全执行层复检。

## 8. 首次真实抓取

真实机械臂测试必须有人在急停旁监护，先移除负载和障碍物，并把速度保持在 10% 或更低。顺序如下：

```bash
./scripts/run.sh doctor --require-can --handeye config/handeye_orbbec_fixed.yaml
./scripts/run.sh read-arm --can can0
./scripts/run.sh grasp --can can0 \
  --object-pose /tmp/object_pose.yaml \
  --recipe config/grasp_recipe.yaml \
  --handeye config/handeye_orbbec_fixed.yaml \
  --scene config/scene.yaml \
  --report logs/first_grasp.yaml
```

上面的命令只连接、读取并规划，不会使能或运动。确认计划、现场、急停和目标位姿都正确后，才在命令末尾显式增加：

```text
--execute --confirmation I_HAVE_CLEARED_THE_WORKSPACE
```

执行期间任何反馈频率下降、时间戳停止、关节步长超限、碰撞或总超时都会停止继续发送目标。软件停止不是功能安全急停，物理急停和隔离区域仍然必需。

## 9. 精度结论

TCP 标定和手眼标定是精确抓取的必要条件，但不是充分条件。最终误差还取决于：

- 相机内参、畸变、深度/标记检测和时间同步。
- URDF/DH 参数是否与机械臂硬件版本一致。
- 夹爪指尖几何、物体尺寸、夹持配方和夹爪回差。
- 基座安装刚度、关节回差、负载变形和温漂。
- 场景坐标测量、碰撞模型近似和目标遮挡。
- 抓取前最后一次视觉复测或闭环视觉伺服。

本工程解决的是原 SDK 单点逆解盲区较多、缺少多候选和碰撞检查的问题，但不能在没有真实标定和重复误差数据时承诺毫米级精度。建议在 10 到 20 个独立检查点记录位置/姿态误差，按 P95 误差决定抓取容差；要求更高时增加抓取前的视觉闭环修正。

## 上游项目

- Piper SDK: <https://github.com/agilexrobotics/piper_sdk>
- Piper ROS: <https://github.com/agilexrobotics/piper_ros>
- Pinocchio: <https://stack-of-tasks.github.io/pinocchio/>
- Pink: <https://github.com/stephane-caron/pink>
